function switchdark() 
{
   var body = document.body;
   body.classList.toggle("darkmode");
   let button = document.getElementById('darkmode');
   if(button.innerHTML == "Dark"){
    button.innerHTML = "Light";
   }
   else{
    button.innerHTML = "Dark"
   }
}